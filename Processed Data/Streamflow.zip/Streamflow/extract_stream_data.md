# Extract Stream Data for Ganga Rivers

This document describes the process of extracting monthly streamflow data for Ganga Basin rivers from raw NetCDF data.

## Overview

The `extract_stream_data.py` script matches stream segment IDs from a shapefile to a NetCDF dataset containing monthly streamflow values, and exports the matched data to CSV format.

## Input Files

| File | Path | Description |
|------|------|-------------|
| Shapefile | `Shapefiles/Ganga Basin Streams/NamedStreams/ganga_rivers.shp` | Contains 1,526 river segments with `seg_id` and `river_name` attributes |
| NetCDF | `Raw Data/Streamflow/Streamflow.nc` | Monthly streamflow data (9,579 segments × 852 months) |

### Shapefile Fields

| Field | Description |
|-------|-------------|
| `seg_id` | Unique stream segment identifier |
| `river_name` | Name of the river |
| `tier` | River tier/order |
| `start_lon`, `start_lat` | Starting coordinates |
| `end_lon`, `end_lat` | Ending coordinates |
| `Length` | Segment length |
| `TopElev`, `BotElev` | Elevation values |

### NetCDF Structure

- **Dimensions**: `seg_id` (9,579) × `time` (852)
- **Variables**:
  - `seg_id`: Stream segment identifiers
  - `time`: Monthly offsets (1-852, representing months since January 1951)
  - `Streamflow`: Streamflow values in m³/s

## Output Files

| File | Path | Description |
|------|------|-------------|
| Streamflow CSV | `Processed Data/ganga_rivers_monthly_streamflow.csv` | Monthly streamflow for matched segments |
| Missing Segments | `Processed Data/missing_segments.csv` | Segments in shapefile but not in NetCDF (with river names) |

### Streamflow CSV Columns

| Column | Description |
|--------|-------------|
| `date` | Calendar date (YYYY-MM-DD) |
| `time` | Original month offset (1-852) |
| `seg_id` | Stream segment ID |
| `streamflow_m3s` | Streamflow in cubic meters per second |

### Missing Segments CSV Columns

| Column | Description |
|--------|-------------|
| `seg_id` | Stream segment ID not found in NetCDF |
| `river_name` | Name of the river for that segment |

## Processing Steps

1. **Read shapefile**: Extract `seg_id` and `river_name` pairs from `ganga_rivers.shp`

2. **Open NetCDF**: Load `Streamflow.nc` with time decoding disabled (time stored as month offsets)

3. **Match segments**: Find intersection between shapefile seg_ids and NetCDF seg_ids

4. **Report missing**: Identify and save any seg_ids present in shapefile but missing from NetCDF

5. **Subset data**: Extract streamflow values only for matching segments

6. **Convert dates**: Transform numeric month offsets to calendar dates
   ```
   base_date = January 1, 1951
   date = base_date + (month_offset) months
   ```

7. **Export CSV**: Save processed data with columns: date, time, seg_id, streamflow_m3s

## Usage

```bash
# Activate virtual environment
source .venv/bin/activate

# Run the script
python scripts/extract_stream_data.py
```

## Dependencies

- `pyshp` (shapefile) - Read shapefiles
- `xarray` - Read NetCDF files
- `pandas` - Data manipulation and CSV export

## Data Coverage

- **Time range**: February 1951 to January 2022 (852 months)
- **Segments**: 1,526 Ganga Basin river segments
- **Total records**: ~1.3 million rows (1,526 segments × 852 months)
